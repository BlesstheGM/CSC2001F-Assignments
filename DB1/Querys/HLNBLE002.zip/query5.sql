SELECT country from offices where state is null
