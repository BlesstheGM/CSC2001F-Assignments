Select city, country From offices ORDER BY country, city;








