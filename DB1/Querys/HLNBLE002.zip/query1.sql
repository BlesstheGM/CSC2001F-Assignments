Select * From productlines;
